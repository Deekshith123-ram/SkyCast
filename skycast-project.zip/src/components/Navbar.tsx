import React, { useState, useEffect, useRef } from 'react';
import { LocationData } from '../types/weather';
import {
  searchLocations,
  ALL_KARNATAKA_DISTRICTS,
  DEFAULT_LOCATION,
  KARNATAKA_DEFAULT_LOCATION,
} from '../services/geocodingService';
import { PWAInstallButton } from './PWAInstallButton';
import {
  Satellite,
  Search,
  MapPin,
  RefreshCw,
  Moon,
  Sun,
  Settings,
  Navigation,
  X,
  Sparkles,
  Check,
} from 'lucide-react';

interface NavbarProps {
  currentLocation: LocationData;
  onSelectLocation: (loc: LocationData) => void;
  onRefresh: () => void;
  isLoading: boolean;
  theme: 'dark' | 'light';
  setTheme: (t: 'dark' | 'light') => void;
  onOpenSettings: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  currentLocation,
  onSelectLocation,
  onRefresh,
  isLoading,
  theme,
  setTheme,
  onOpenSettings,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [searchResults, setSearchResults] = useState<LocationData[]>([]);
  const [isSearching, setIsSearching] = useState(false);
  const [isDropdownOpen, setIsDropdownOpen] = useState(false);
  const [isLocating, setIsLocating] = useState(false);
  const searchContainerRef = useRef<HTMLDivElement>(null);

  // Debounced search
  useEffect(() => {
    if (!searchQuery.trim()) {
      setSearchResults([KARNATAKA_DEFAULT_LOCATION, ...ALL_KARNATAKA_DISTRICTS.slice(0, 10)]);
      return;
    }

    const timer = setTimeout(async () => {
      setIsSearching(true);
      try {
        const results = await searchLocations(searchQuery);
        setSearchResults(results);
      } catch (err) {
        console.error('Search error:', err);
      } finally {
        setIsSearching(false);
      }
    }, 250);

    return () => clearTimeout(timer);
  }, [searchQuery]);

  // Click outside to close dropdown
  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (searchContainerRef.current && !searchContainerRef.current.contains(e.target as Node)) {
        setIsDropdownOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const handleRequestUserLocation = () => {
    if (!navigator.geolocation) {
      alert('Geolocation is not supported by your browser.');
      return;
    }

    setIsLocating(true);
    navigator.geolocation.getCurrentPosition(
      (pos) => {
        setIsLocating(false);
        const userLoc: LocationData = {
          id: `custom-coords-${pos.coords.latitude.toFixed(3)}`,
          name: 'My Current Location',
          district: 'Detected Location',
          state: 'Karnataka',
          country: 'India',
          latitude: Number(pos.coords.latitude.toFixed(4)),
          longitude: Number(pos.coords.longitude.toFixed(4)),
        };
        onSelectLocation(userLoc);
      },
      (err) => {
        setIsLocating(false);
        console.warn('Location permission denied, retaining Karnataka focus.', err);
      },
      { timeout: 8000 }
    );
  };

  // Curated prominent Karnataka pills
  const featuredPills: LocationData[] = [
    KARNATAKA_DEFAULT_LOCATION,
    ALL_KARNATAKA_DISTRICTS.find((d) => d.id === 'tumakuru-ka') || ALL_KARNATAKA_DISTRICTS[0],
    ALL_KARNATAKA_DISTRICTS.find((d) => d.id === 'bengaluru-urban-ka') || ALL_KARNATAKA_DISTRICTS[1],
    ALL_KARNATAKA_DISTRICTS.find((d) => d.id === 'mysuru-ka') || ALL_KARNATAKA_DISTRICTS[3],
    ALL_KARNATAKA_DISTRICTS.find((d) => d.id === 'mangaluru-ka') || ALL_KARNATAKA_DISTRICTS[4],
    ALL_KARNATAKA_DISTRICTS.find((d) => d.id === 'shivamogga-ka') || ALL_KARNATAKA_DISTRICTS[7],
    ALL_KARNATAKA_DISTRICTS.find((d) => d.id === 'belagavi-ka') || ALL_KARNATAKA_DISTRICTS[23],
    ALL_KARNATAKA_DISTRICTS.find((d) => d.id === 'dharwad-ka') || ALL_KARNATAKA_DISTRICTS[22],
    ALL_KARNATAKA_DISTRICTS.find((d) => d.id === 'kalaburagi-ka') || ALL_KARNATAKA_DISTRICTS[28],
    ALL_KARNATAKA_DISTRICTS.find((d) => d.id === 'ballari-ka') || ALL_KARNATAKA_DISTRICTS[18],
    ALL_KARNATAKA_DISTRICTS.find((d) => d.id === 'udupi-ka') || ALL_KARNATAKA_DISTRICTS[5],
  ];

  return (
    <header className="sticky top-0 z-40 w-full pt-[env(safe-area-inset-top)] bg-white/95 dark:bg-[#050b18]/95 backdrop-blur-xl border-b border-slate-200 dark:border-cyan-500/15 shadow-md dark:shadow-xl transition-colors duration-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-wrap sm:flex-nowrap items-center justify-between gap-x-3 gap-y-2 py-2 sm:py-0 sm:h-20">
          {/* Logo & Branding */}
          <div
            onClick={() => onSelectLocation(DEFAULT_LOCATION)}
            className="order-1 flex items-center gap-3 cursor-pointer group flex-shrink-0"
            title="SkyCast India — Reset to Whole State of Karnataka"
          >
            <div className="relative w-10 h-10 sm:w-11 sm:h-11 rounded-xl bg-gradient-to-tr from-cyan-600 via-blue-600 to-indigo-600 p-[1px] shadow-lg shadow-cyan-900/30">
              <div className="w-full h-full bg-[#071022] rounded-[11px] flex items-center justify-center relative overflow-hidden">
                <Satellite className="w-5 h-5 text-cyan-400 group-hover:scale-110 transition-transform duration-300" />
                <span className="absolute -top-1 -right-1 w-3 h-3 rounded-full bg-cyan-400 animate-ping opacity-60"></span>
              </div>
            </div>

            <div>
              <div className="flex items-center gap-1.5">
                <span className="text-lg sm:text-xl font-extrabold text-slate-900 dark:text-white tracking-tight font-['Space_Grotesk',sans-serif]">
                  SkyCast<span className="text-cyan-600 dark:text-cyan-400">.</span>IN
                </span>
                <span className="px-1.5 py-0.2 rounded bg-cyan-100 text-cyan-800 dark:bg-cyan-950 dark:text-cyan-300 text-[10px] font-mono border border-cyan-300 dark:border-cyan-500/30 font-semibold">
                  KARNATAKA LIVE
                </span>
              </div>
              <p className="text-[10px] text-slate-500 dark:text-slate-400 tracking-wider uppercase font-semibold hidden sm:block">
                All 31 Districts Rain & Satellite Radar
              </p>
            </div>
          </div>

          {/* Search Bar with Autocomplete Dropdown */}
          <div ref={searchContainerRef} className="relative order-2 w-full sm:w-auto sm:flex-1 sm:max-w-md sm:mx-4">
            <div className="relative flex items-center">
              <Search className="absolute left-3.5 w-4 h-4 text-cyan-600 dark:text-cyan-400 pointer-events-none" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                onFocus={() => setIsDropdownOpen(true)}
                placeholder="Search any Karnataka district or Indian city..."
                className="w-full pl-9 pr-16 sm:pr-20 py-2 sm:py-2.5 rounded-xl bg-slate-100 dark:bg-slate-900/80 border border-slate-300 dark:border-cyan-500/25 focus:border-cyan-500 text-xs sm:text-sm text-slate-900 dark:text-slate-100 placeholder-slate-500 focus:outline-none transition shadow-inner"
              />
              {searchQuery && (
                <button
                  onClick={() => setSearchQuery('')}
                  className="absolute right-9 sm:right-10 p-1 text-slate-400 hover:text-slate-800 dark:hover:text-white cursor-pointer"
                >
                  <X className="w-3.5 h-3.5" />
                </button>
              )}
              <button
                onClick={handleRequestUserLocation}
                disabled={isLocating}
                className="absolute right-2.5 p-1 rounded-lg text-cyan-700 dark:text-cyan-400 hover:text-cyan-900 dark:hover:text-cyan-200 transition cursor-pointer"
                title="Detect My Location (Optional)"
              >
                <Navigation className={`w-3.5 h-3.5 ${isLocating ? 'animate-spin' : ''}`} />
              </button>
            </div>

            {/* Dropdown Menu */}
            {isDropdownOpen && (
              <div className="absolute left-0 right-0 mt-2 max-h-80 overflow-y-auto rounded-xl bg-white dark:bg-[#09152b] border border-slate-200 dark:border-cyan-500/30 shadow-2xl p-2 z-50 animate-in fade-in">
                <div className="px-2.5 py-1 text-[10px] font-bold uppercase tracking-wider text-cyan-700 dark:text-cyan-400 flex items-center justify-between border-b border-slate-200 dark:border-slate-800">
                  <span>{searchQuery ? 'Search Results' : 'Karnataka 31 Districts & Hotspots'}</span>
                  {isSearching && <span className="text-cyan-600 dark:text-cyan-400 animate-pulse">Searching...</span>}
                </div>

                <div className="mt-1 space-y-1">
                  {searchResults.map((loc) => {
                    const isSelected =
                      Math.abs(loc.latitude - currentLocation.latitude) < 0.01 &&
                      Math.abs(loc.longitude - currentLocation.longitude) < 0.01;

                    return (
                      <button
                        key={loc.id}
                        onClick={() => {
                          onSelectLocation(loc);
                          setIsDropdownOpen(false);
                          setSearchQuery('');
                        }}
                        className={`w-full text-left px-3 py-2 rounded-lg flex items-center justify-between text-xs transition cursor-pointer ${
                          isSelected
                            ? 'bg-cyan-100 dark:bg-cyan-500/20 text-cyan-900 dark:text-cyan-300 font-semibold'
                            : 'hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-800 dark:text-slate-200'
                        }`}
                      >
                        <div className="flex items-center gap-2.5">
                          <MapPin className={`w-3.5 h-3.5 ${isSelected ? 'text-cyan-600 dark:text-cyan-400' : 'text-slate-400'}`} />
                          <div>
                            <span className="font-semibold block">{loc.name}</span>
                            <span className="text-[10px] text-slate-500 dark:text-slate-400">
                              {loc.district}, {loc.state}
                            </span>
                          </div>
                        </div>

                        {isSelected && <Check className="w-4 h-4 text-cyan-600 dark:text-cyan-400" />}
                      </button>
                    );
                  })}
                </div>
              </div>
            )}
          </div>

          {/* Right Action Icons: Download App, Live Refresh, Theme Toggle, Settings
              On phones these move to the fixed bottom MobileActionBar */}
          <div className="hidden sm:block order-3 flex-none">
          <div className="flex items-center gap-2 p-1">
            {/* Download App for Android / Desktop - Hidden once downloaded */}
            <PWAInstallButton />

            <button
              onClick={onRefresh}
              disabled={isLoading}
              className="p-2 sm:p-2.5 rounded-xl bg-slate-100 hover:bg-slate-200 dark:bg-slate-900/80 dark:hover:bg-cyan-950 border border-slate-300 dark:border-slate-800 text-slate-700 dark:text-slate-300 hover:text-cyan-700 dark:hover:text-cyan-300 transition active:scale-95 cursor-pointer shadow-sm relative"
              title="Refresh Live Weather & Satellite Feeds"
            >
              <RefreshCw className={`w-4 h-4 ${isLoading ? 'animate-spin text-cyan-600 dark:text-cyan-400' : ''}`} />
              <span className="absolute -top-1 -right-1 flex h-2.5 w-2.5">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-emerald-500"></span>
              </span>
            </button>

            <button
              onClick={() => setTheme(theme === 'dark' ? 'light' : 'dark')}
              className="p-2 sm:p-2.5 rounded-xl bg-slate-100 hover:bg-slate-200 dark:bg-slate-900/80 dark:hover:bg-cyan-950 border border-slate-300 dark:border-slate-800 text-slate-700 dark:text-slate-300 hover:text-amber-600 dark:hover:text-amber-300 transition active:scale-95 cursor-pointer shadow-sm"
              title={`Switch to ${theme === 'dark' ? 'Light' : 'Dark'} Theme`}
            >
              {theme === 'dark' ? <Sun className="w-4 h-4" /> : <Moon className="w-4 h-4" />}
            </button>

            <button
              onClick={onOpenSettings}
              className="p-2 sm:p-2.5 rounded-xl bg-slate-100 hover:bg-slate-200 dark:bg-slate-900/80 dark:hover:bg-cyan-950 border border-slate-300 dark:border-slate-800 text-slate-700 dark:text-slate-300 hover:text-cyan-700 dark:hover:text-cyan-300 transition active:scale-95 cursor-pointer shadow-sm"
              title="Platform Settings & Info"
            >
              <Settings className="w-4 h-4" />
            </button>
          </div>
          </div>
        </div>

        {/* Quick Karnataka District Pills */}
        <div className="flex items-center gap-1.5 overflow-x-auto py-2 no-scrollbar text-xs border-t border-slate-200 dark:border-slate-800/60">
          <span className="text-[10px] text-cyan-700 dark:text-cyan-400 uppercase tracking-wider font-bold mr-1 flex-shrink-0 flex items-center gap-1">
            <Sparkles className="w-3 h-3" />
            Karnataka:
          </span>
          {featuredPills.map((loc) => {
            const isCurrent =
              Math.abs(loc.latitude - currentLocation.latitude) < 0.01 &&
              Math.abs(loc.longitude - currentLocation.longitude) < 0.01;

            return (
              <button
                key={loc.id}
                onClick={() => onSelectLocation(loc)}
                className={`flex-shrink-0 px-2.5 py-1 rounded-lg font-medium transition cursor-pointer text-xs ${
                  isCurrent
                    ? 'bg-cyan-100 dark:bg-cyan-500/25 text-cyan-900 dark:text-cyan-300 border border-cyan-400 font-bold shadow-sm'
                    : 'bg-white dark:bg-slate-900/60 hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-700 dark:text-slate-300 border border-slate-200 dark:border-slate-800'
                }`}
              >
                {loc.name}
              </button>
            );
          })}
        </div>
      </div>
    </header>
  );
};
