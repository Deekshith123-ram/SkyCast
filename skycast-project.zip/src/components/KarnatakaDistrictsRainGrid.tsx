import React, { useState } from 'react';
import { DistrictRainData, LocationData } from '../types/weather';
import {
  Droplets,
  CloudRain,
  Search,
  ArrowUpDown,
  MapPin,
} from 'lucide-react';

interface KarnatakaDistrictsRainGridProps {
  districts: DistrictRainData[];
  selectedLocation: LocationData;
  onSelectDistrict: (loc: LocationData) => void;
}

export const KarnatakaDistrictsRainGrid: React.FC<KarnatakaDistrictsRainGridProps> = ({
  districts,
  selectedLocation,
  onSelectDistrict,
}) => {
  const [filterRegion, setFilterRegion] = useState<string>('all');
  const [filterRainCategory, setFilterRainCategory] = useState<'all' | 'high' | 'moderate' | 'low'>('all');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [sortBy, setSortBy] = useState<'prob_desc' | 'rain_desc' | 'name_asc'>('prob_desc');

  // Filter logic
  const filteredDistricts = districts.filter((d) => {
    const matchesSearch =
      d.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      d.district.toLowerCase().includes(searchQuery.toLowerCase());

    const matchesRegion = filterRegion === 'all' || d.region === filterRegion;

    const matchesCategory =
      filterRainCategory === 'all' ||
      (filterRainCategory === 'high' && d.rainProbability >= 60) ||
      (filterRainCategory === 'moderate' && d.rainProbability >= 30 && d.rainProbability < 60) ||
      (filterRainCategory === 'low' && d.rainProbability < 30);

    return matchesSearch && matchesRegion && matchesCategory;
  });

  // Sort logic
  filteredDistricts.sort((a, b) => {
    if (sortBy === 'prob_desc') return b.rainProbability - a.rainProbability;
    if (sortBy === 'rain_desc') return b.precipitationSum - a.precipitationSum;
    return a.district.localeCompare(b.district);
  });

  // Summary counts
  const highRiskCount = districts.filter((d) => d.rainProbability >= 60).length;

  return (
    <div className="w-full glass-panel rounded-2xl p-5 md:p-6 transition-colors duration-200">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-4 border-b border-slate-200 dark:border-cyan-500/15">
        <div>
          <div className="flex items-center gap-2">
            <span className="p-1.5 rounded-lg bg-blue-100 dark:bg-blue-500/20 text-blue-700 dark:text-cyan-400">
              <CloudRain className="w-4 h-4" />
            </span>
            <h2 className="text-base sm:text-lg font-bold text-slate-900 dark:text-white tracking-tight">
              Karnataka Rain Probability Monitor (All 31 Districts)
            </h2>
          </div>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
            Real-time numerical probability of precipitation and expected accumulations across Karnataka
          </p>
        </div>

        {/* Quick status pill */}
        <div className="flex items-center gap-2">
          {highRiskCount > 0 && (
            <span className="px-2.5 py-1 rounded-full bg-blue-100 dark:bg-blue-950/80 text-blue-800 dark:text-blue-300 border border-blue-300 dark:border-blue-500/30 text-xs font-semibold flex items-center gap-1.5">
              <span className="w-2 h-2 rounded-full bg-blue-600 dark:bg-blue-400 animate-pulse"></span>
              {highRiskCount} Districts High Rain Risk (&ge;60%)
            </span>
          )}
          <span className="px-2.5 py-1 rounded-full bg-slate-100 dark:bg-slate-900 text-slate-700 dark:text-slate-300 border border-slate-300 dark:border-slate-700 text-xs font-mono">
            31 Districts Active
          </span>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="mt-4 flex flex-col md:flex-row items-stretch md:items-center justify-between gap-3">
        {/* Search Input */}
        <div className="relative flex-1 max-w-sm">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-cyan-600 dark:text-cyan-400 pointer-events-none" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search Karnataka district (e.g. Tumakuru, Udupi)..."
            className="w-full pl-9 pr-3 py-1.5 rounded-xl bg-slate-50 dark:bg-slate-900/80 border border-slate-300 dark:border-slate-700 focus:border-cyan-500 text-xs text-slate-900 dark:text-slate-100 placeholder-slate-400 dark:placeholder-slate-500 focus:outline-none"
          />
        </div>

        {/* Filter Pills */}
        <div className="flex items-center gap-1.5 overflow-x-auto no-scrollbar text-xs">
          <button
            onClick={() => setFilterRainCategory('all')}
            className={`px-2.5 py-1 rounded-lg font-medium transition cursor-pointer ${
              filterRainCategory === 'all'
                ? 'bg-cyan-100 dark:bg-cyan-500/25 text-cyan-900 dark:text-cyan-200 border border-cyan-400 font-bold'
                : 'bg-slate-100 dark:bg-slate-900/70 text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white border border-slate-200 dark:border-slate-800'
            }`}
          >
            All Probabilities
          </button>
          <button
            onClick={() => setFilterRainCategory('high')}
            className={`px-2.5 py-1 rounded-lg font-medium transition cursor-pointer ${
              filterRainCategory === 'high'
                ? 'bg-blue-100 dark:bg-blue-600/30 text-blue-900 dark:text-blue-300 border border-blue-400 font-bold'
                : 'bg-slate-100 dark:bg-slate-900/70 text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white border border-slate-200 dark:border-slate-800'
            }`}
          >
            🌧️ High (&ge;60%)
          </button>
          <button
            onClick={() => setFilterRainCategory('moderate')}
            className={`px-2.5 py-1 rounded-lg font-medium transition cursor-pointer ${
              filterRainCategory === 'moderate'
                ? 'bg-cyan-100 dark:bg-cyan-600/30 text-cyan-900 dark:text-cyan-300 border border-cyan-400 font-bold'
                : 'bg-slate-100 dark:bg-slate-900/70 text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white border border-slate-200 dark:border-slate-800'
            }`}
          >
            🌦️ Moderate (30–59%)
          </button>
          <button
            onClick={() => setFilterRainCategory('low')}
            className={`px-2.5 py-1 rounded-lg font-medium transition cursor-pointer ${
              filterRainCategory === 'low'
                ? 'bg-emerald-100 dark:bg-emerald-600/30 text-emerald-900 dark:text-emerald-300 border border-emerald-400 font-bold'
                : 'bg-slate-100 dark:bg-slate-900/70 text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white border border-slate-200 dark:border-slate-800'
            }`}
          >
            🌤️ Low (&lt;30%)
          </button>
        </div>

        {/* Sort Selector */}
        <div className="flex items-center gap-1.5 text-xs text-slate-600 dark:text-slate-400">
          <ArrowUpDown className="w-3.5 h-3.5 text-cyan-600 dark:text-cyan-400" />
          <select
            value={sortBy}
            onChange={(e: any) => setSortBy(e.target.value)}
            className="bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 text-slate-800 dark:text-slate-200 rounded-lg px-2 py-1 text-xs focus:outline-none focus:border-cyan-500"
          >
            <option value="prob_desc">Rain Probability (High to Low)</option>
            <option value="rain_desc">Expected Rainfall (mm)</option>
            <option value="name_asc">District Name (A–Z)</option>
          </select>
        </div>
      </div>

      {/* Region Selector Pills */}
      <div className="mt-3 flex items-center gap-2 overflow-x-auto no-scrollbar pb-1 text-xs text-slate-600 dark:text-slate-400">
        <span className="text-[10px] uppercase font-bold text-slate-400 dark:text-slate-500 flex-shrink-0">Region:</span>
        {['all', 'Coastal', 'Malnad (Ghats)', 'South Interior', 'North Interior'].map((reg) => (
          <button
            key={reg}
            onClick={() => setFilterRegion(reg)}
            className={`flex-shrink-0 px-2 py-0.5 rounded-md text-[11px] font-medium transition cursor-pointer ${
              filterRegion === reg
                ? 'bg-cyan-100 text-cyan-900 border border-cyan-400 dark:bg-cyan-950 dark:text-cyan-300 dark:border-cyan-500/40 font-semibold'
                : 'hover:text-slate-900 dark:hover:text-slate-200 text-slate-600 dark:text-slate-400'
            }`}
          >
            {reg === 'all' ? 'All Karnataka' : reg}
          </button>
        ))}
      </div>

      {/* District Cards Grid */}
      <div className="mt-4 grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-3 max-h-[460px] overflow-y-auto pr-1">
        {filteredDistricts.map((d) => {
          const isSelected =
            Math.abs(d.latitude - selectedLocation.latitude) < 0.05 &&
            Math.abs(d.longitude - selectedLocation.longitude) < 0.05;

          const isHigh = d.rainProbability >= 60;
          const isMod = d.rainProbability >= 30 && d.rainProbability < 60;

          return (
            <div
              key={d.id}
              onClick={() =>
                onSelectDistrict({
                  id: d.id,
                  name: d.name,
                  district: d.district,
                  state: 'Karnataka',
                  country: 'India',
                  latitude: d.latitude,
                  longitude: d.longitude,
                })
              }
              className={`p-3.5 rounded-xl border transition-all cursor-pointer flex flex-col justify-between ${
                isSelected
                  ? 'bg-cyan-50 dark:bg-cyan-950/40 border-cyan-500 dark:border-cyan-400 shadow-md ring-1 ring-cyan-500'
                  : 'bg-white dark:bg-slate-900/50 border-slate-200 dark:border-slate-800/90 hover:bg-slate-50 dark:hover:bg-slate-900/80 hover:border-cyan-400 shadow-sm'
              }`}
            >
              {/* Top row: Name & Region */}
              <div className="flex items-start justify-between gap-1 mb-2">
                <div>
                  <h4 className="text-xs font-bold text-slate-900 dark:text-white flex items-center gap-1">
                    <MapPin className={`w-3 h-3 ${isSelected ? 'text-cyan-600 dark:text-cyan-400' : 'text-slate-400'}`} />
                    <span>{d.district}</span>
                  </h4>
                  <span className="text-[10px] text-slate-500 dark:text-slate-400 block mt-0.5">{d.region}</span>
                </div>

                {/* Rain Probability Pill */}
                <div
                  className={`px-2 py-0.5 rounded-full text-xs font-mono font-bold flex items-center gap-1 shadow-sm ${
                    isHigh
                      ? 'bg-blue-100 text-blue-900 border border-blue-300 dark:bg-blue-600/30 dark:text-blue-300 dark:border-blue-500/40'
                      : isMod
                      ? 'bg-cyan-100 text-cyan-900 border border-cyan-300 dark:bg-cyan-600/30 dark:text-cyan-300 dark:border-cyan-500/40'
                      : 'bg-slate-100 text-slate-700 border border-slate-200 dark:bg-slate-800 dark:text-slate-300 dark:border-slate-700'
                  }`}
                >
                  <Droplets className="w-3 h-3 text-cyan-600 dark:text-cyan-400" />
                  <span>{d.rainProbability}%</span>
                </div>
              </div>

              {/* Progress bar visual for rain probability */}
              <div className="w-full h-1.5 rounded-full bg-slate-200 dark:bg-slate-800 overflow-hidden mb-2">
                <div
                  className={`h-full rounded-full transition-all duration-500 ${
                    isHigh
                      ? 'bg-gradient-to-r from-blue-500 to-indigo-600'
                      : isMod
                      ? 'bg-gradient-to-r from-cyan-400 to-blue-500'
                      : 'bg-slate-400 dark:bg-slate-600'
                  }`}
                  style={{ width: `${Math.max(4, d.rainProbability)}%` }}
                />
              </div>

              {/* Bottom details: Expected Rain & Temp */}
              <div className="flex items-center justify-between text-[11px] pt-1.5 border-t border-slate-100 dark:border-slate-800/80 text-slate-600 dark:text-slate-300">
                <span className="text-slate-500 dark:text-slate-400">
                  Rain: <strong className="text-slate-900 dark:text-white font-mono">{d.precipitationSum} mm</strong>
                </span>
                <span className="text-slate-500 dark:text-slate-400 font-mono">
                  {d.tempMin}° / <strong className="text-slate-900 dark:text-white">{d.tempMax}°C</strong>
                </span>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
