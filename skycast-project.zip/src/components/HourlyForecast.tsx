import React, { useRef } from 'react';
import { HourlyForecastItem } from '../types/weather';
import {
  Sun,
  CloudSun,
  Cloud,
  CloudRain,
  CloudLightning,
  ChevronLeft,
  ChevronRight,
  Droplets,
  Wind,
} from 'lucide-react';

interface HourlyForecastProps {
  hourly: HourlyForecastItem[];
}

export const HourlyForecast: React.FC<HourlyForecastProps> = ({ hourly }) => {
  const scrollContainerRef = useRef<HTMLDivElement>(null);

  const scroll = (direction: 'left' | 'right') => {
    if (!scrollContainerRef.current) return;
    const scrollAmount = direction === 'left' ? -320 : 320;
    scrollContainerRef.current.scrollBy({ left: scrollAmount, behavior: 'smooth' });
  };

  const getHourlyIcon = (code: number) => {
    if (code === 0) return <Sun className="w-6 h-6 text-amber-500 dark:text-amber-400" />;
    if (code <= 2) return <CloudSun className="w-6 h-6 text-cyan-600 dark:text-cyan-300" />;
    if (code === 3) return <Cloud className="w-6 h-6 text-slate-500 dark:text-slate-300" />;
    if (code >= 51 && code <= 82) return <CloudRain className="w-6 h-6 text-blue-600 dark:text-blue-400" />;
    if (code >= 95) return <CloudLightning className="w-6 h-6 text-amber-500 dark:text-amber-400" />;
    return <Cloud className="w-6 h-6 text-slate-500 dark:text-slate-400" />;
  };

  return (
    <div className="w-full glass-panel rounded-2xl p-5 border border-slate-300/80 dark:border-cyan-500/20 shadow-xl">
      <div className="flex items-center justify-between pb-3 mb-3 border-b border-slate-200 dark:border-cyan-500/15">
        <div>
          <h2 className="text-base font-bold text-slate-900 dark:text-white flex items-center gap-2">
            <span className="w-2.5 h-2.5 rounded-full bg-cyan-600 dark:bg-cyan-400"></span>
            Hourly Telemetry Forecast (Next 48 Hours)
          </h2>
          <p className="text-xs text-slate-600 dark:text-slate-400 mt-0.5">
            Diurnal temperature variance, cloud cover & precipitation probability
          </p>
        </div>

        <div className="flex items-center gap-1">
          <button
            onClick={() => scroll('left')}
            className="p-1.5 rounded-lg bg-white dark:bg-slate-900/60 hover:bg-slate-100 dark:hover:bg-cyan-500/20 border border-slate-300 dark:border-slate-800 text-slate-700 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white transition cursor-pointer shadow-sm"
            title="Scroll Left"
          >
            <ChevronLeft className="w-4 h-4" />
          </button>
          <button
            onClick={() => scroll('right')}
            className="p-1.5 rounded-lg bg-white dark:bg-slate-900/60 hover:bg-slate-100 dark:hover:bg-cyan-500/20 border border-slate-300 dark:border-slate-800 text-slate-700 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white transition cursor-pointer shadow-sm"
            title="Scroll Right"
          >
            <ChevronRight className="w-4 h-4" />
          </button>
        </div>
      </div>

      <div
        ref={scrollContainerRef}
        className="flex items-center gap-3 overflow-x-auto pb-2 pt-1 no-scrollbar scroll-smooth"
      >
        {hourly.map((item, idx) => (
          <div
            key={item.time}
            className={`flex-shrink-0 w-32 p-3.5 rounded-xl border flex flex-col items-center justify-between transition-all shadow-sm ${
              idx === 0
                ? 'bg-cyan-50 dark:bg-cyan-950/50 border-cyan-400 dark:border-cyan-500/50 shadow-md ring-1 ring-cyan-400/50'
                : 'bg-white/90 dark:bg-slate-900/50 border-slate-200 dark:border-slate-800/80 hover:border-cyan-400 dark:hover:border-cyan-500/40 hover:bg-slate-50 dark:hover:bg-slate-900/80'
            }`}
          >
            {/* Hour time */}
            <span className="text-xs font-semibold text-slate-700 dark:text-slate-300 font-mono">
              {idx === 0 ? 'Now' : item.formattedTime}
            </span>

            {/* Icon */}
            <div className="my-2.5">{getHourlyIcon(item.weatherCode)}</div>

            {/* Temperature */}
            <span className="text-xl font-extrabold text-slate-900 dark:text-white font-mono">{item.temperature}°</span>

            {/* Rain Probability & Amount */}
            <div className="w-full mt-2 pt-2 border-t border-slate-200 dark:border-slate-800/80 flex flex-col gap-1 text-[10px]">
              <div className="flex items-center justify-between text-cyan-700 dark:text-cyan-300">
                <span className="flex items-center gap-1 font-medium">
                  <Droplets className="w-3 h-3 text-cyan-600 dark:text-cyan-400" />
                  Rain
                </span>
                <span className="font-mono font-bold">{item.precipitationProbability}%</span>
              </div>

              {item.precipitation > 0 && (
                <div className="flex items-center justify-between text-blue-600 dark:text-blue-400 font-mono text-[9px] font-semibold">
                  <span>Precip</span>
                  <span>{item.precipitation} mm</span>
                </div>
              )}

              {/* Wind & Clouds */}
              <div className="flex items-center justify-between text-slate-500 dark:text-slate-400 mt-0.5">
                <span className="flex items-center gap-1">
                  <Wind className="w-3 h-3 text-teal-600 dark:text-teal-400" />
                  {item.windSpeed} km/h
                </span>
                <span className="text-[9px] font-mono text-slate-500">{item.cloudCover}% cld</span>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
