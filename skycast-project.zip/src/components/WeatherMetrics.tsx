import React from 'react';
import { CurrentWeather, DailyForecastItem } from '../types/weather';
import { getWindDirectionLabel } from '../services/weatherService';
import {
  Droplets,
  Wind,
  Compass,
  CloudRain,
  Cloud,
  Sun,
  Gauge,
  Eye,
  ThermometerSnowflake,
} from 'lucide-react';

interface WeatherMetricsProps {
  current: CurrentWeather;
  today?: DailyForecastItem;
}

export const WeatherMetrics: React.FC<WeatherMetricsProps> = ({ current, today }) => {
  const getUvLevel = (uv: number): { label: string; color: string } => {
    if (uv <= 2) return { label: 'Low', color: 'text-emerald-600 dark:text-emerald-400' };
    if (uv <= 5) return { label: 'Moderate', color: 'text-yellow-600 dark:text-yellow-400' };
    if (uv <= 7) return { label: 'High', color: 'text-amber-600 dark:text-amber-400' };
    if (uv <= 10) return { label: 'Very High', color: 'text-orange-600 dark:text-orange-400' };
    return { label: 'Extreme', color: 'text-rose-600 dark:text-rose-500' };
  };

  const uvInfo = getUvLevel(current.uvIndex);
  const windDirLabel = getWindDirectionLabel(current.windDirection);

  const metrics = [
    {
      id: 'humidity',
      label: 'Relative Humidity',
      value: `${current.relativeHumidity}%`,
      subtitle: current.relativeHumidity > 70 ? 'High Moisture' : 'Comfortable',
      icon: <Droplets className="w-4 h-4 text-cyan-600 dark:text-cyan-400" />,
      bg: 'bg-cyan-100 dark:bg-cyan-500/10',
      border: 'border-slate-200 dark:border-cyan-500/20',
    },
    {
      id: 'wind',
      label: 'Wind Speed & Gusts',
      value: `${current.windSpeed} km/h`,
      subtitle: `Gusts up to ${current.windGusts} km/h`,
      icon: <Wind className="w-4 h-4 text-teal-600 dark:text-teal-400" />,
      bg: 'bg-teal-100 dark:bg-teal-500/10',
      border: 'border-slate-200 dark:border-teal-500/20',
    },
    {
      id: 'wind_dir',
      label: 'Wind Direction',
      value: `${current.windDirection}°`,
      subtitle: windDirLabel,
      icon: <Compass className="w-4 h-4 text-blue-600 dark:text-blue-400" />,
      bg: 'bg-blue-100 dark:bg-blue-500/10',
      border: 'border-slate-200 dark:border-blue-500/20',
    },
    {
      id: 'rain_prob',
      label: 'Rain Probability',
      value: `${today?.precipitationProbabilityMax ?? 0}%`,
      subtitle: today?.precipitationSum ? `${today.precipitationSum} mm expected` : 'Negligible rain',
      icon: <CloudRain className="w-4 h-4 text-indigo-600 dark:text-indigo-400" />,
      bg: 'bg-indigo-100 dark:bg-indigo-500/10',
      border: 'border-slate-200 dark:border-indigo-500/20',
    },
    {
      id: 'cloud_cover',
      label: 'Cloud Coverage',
      value: `${current.cloudCover}%`,
      subtitle: current.cloudCover > 60 ? 'Overcast Sky' : current.cloudCover > 25 ? 'Scattered Clouds' : 'Clear Sky',
      icon: <Cloud className="w-4 h-4 text-slate-600 dark:text-slate-300" />,
      bg: 'bg-slate-200 dark:bg-slate-500/10',
      border: 'border-slate-200 dark:border-slate-500/20',
    },
    {
      id: 'uv_index',
      label: 'UV Radiation Index',
      value: `${current.uvIndex}`,
      subtitle: `${uvInfo.label} Risk`,
      subtitleColor: uvInfo.color,
      icon: <Sun className="w-4 h-4 text-amber-600 dark:text-amber-400" />,
      bg: 'bg-amber-100 dark:bg-amber-500/10',
      border: 'border-slate-200 dark:border-amber-500/20',
    },
    {
      id: 'pressure',
      label: 'Atmospheric Pressure',
      value: `${current.surfacePressure} hPa`,
      subtitle: 'Barometric Surface',
      icon: <Gauge className="w-4 h-4 text-purple-600 dark:text-purple-400" />,
      bg: 'bg-purple-100 dark:bg-purple-500/10',
      border: 'border-slate-200 dark:border-purple-500/20',
    },
    {
      id: 'visibility',
      label: 'Surface Visibility',
      value: `${current.visibility ?? 10} km`,
      subtitle: (current.visibility ?? 10) >= 10 ? 'Optimal Clearness' : 'Atmospheric Haze',
      icon: <Eye className="w-4 h-4 text-emerald-600 dark:text-emerald-400" />,
      bg: 'bg-emerald-100 dark:bg-emerald-500/10',
      border: 'border-slate-200 dark:border-emerald-500/20',
    },
    {
      id: 'dew_point',
      label: 'Dew Point',
      value: `${current.dewPoint ?? Math.round(current.temperature - (100 - current.relativeHumidity) / 5)}°C`,
      subtitle: 'Condensation Point',
      icon: <ThermometerSnowflake className="w-4 h-4 text-sky-600 dark:text-sky-400" />,
      bg: 'bg-sky-100 dark:bg-sky-500/10',
      border: 'border-slate-200 dark:border-sky-500/20',
    },
  ];

  return (
    <div className="w-full">
      <div className="flex items-center justify-between mb-3 px-1">
        <h2 className="text-sm font-bold text-slate-700 dark:text-slate-300 uppercase tracking-wider flex items-center gap-2">
          <span className="w-2 h-2 rounded-full bg-cyan-600 dark:bg-cyan-400"></span>
          Key Meteorological Metrics
        </h2>
        <span className="text-[11px] text-slate-500 dark:text-slate-400 font-mono">Real-Time Sensor Suite</span>
      </div>

      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-9 gap-3">
        {metrics.map((m) => (
          <div
            key={m.id}
            className={`p-3.5 rounded-xl glass-panel glass-panel-hover border ${m.border} flex flex-col justify-between`}
          >
            <div className="flex items-center justify-between mb-2">
              <span className="text-[11px] font-medium text-slate-600 dark:text-slate-400 line-clamp-1">{m.label}</span>
              <div className={`p-1.5 rounded-lg ${m.bg}`}>{m.icon}</div>
            </div>

            <div>
              <div className="text-xl font-bold text-slate-900 dark:text-white font-mono tracking-tight">{m.value}</div>
              <div className={`text-[10px] mt-0.5 truncate ${m.subtitleColor || 'text-slate-500 dark:text-slate-400'}`}>
                {m.subtitle}
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
